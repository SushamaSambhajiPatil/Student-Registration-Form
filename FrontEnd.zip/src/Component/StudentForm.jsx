import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function StudentForm() {
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    addName: [{ addAddressName: "" }],
    dob: "",
    pincode: "",
    course: "",
    email: ""
  });

  const [newData, setNewData] = useState([]);
  const [id, setId] = useState(undefined);

  // Fetch student data
  function loadData() {
    axios.get("http://localhost:8080/student/")
      .then((res) => {
        setNewData(res.data);
        console.log("Loaded student data:", res.data);
      })
      .catch((err) => {
        console.error("Error loading data:", err);
      });
  }

  useEffect(() => {
    loadData();
  }, []);

  // Delete a student by id
  function handleDelete(id) {
    axios.delete("http://localhost:8080/student/" + id)
      .then((res) => {
        console.log("Deleted student:", res.data);
        loadData();
      })
      .catch((err) => {
        console.error("Error deleting student:", err);
      });
  }

  // Update a student by id
  function handleUpdate(id) {
    setId(id);
    axios.get("http://localhost:8080/student/" + id)
      .then((res) => {
        setData({
          firstName: res.data.firstName,
          lastName: res.data.lastName,
          addName: res.data.addName,
          dob: res.data.dob,
          pincode: res.data.pincode,
          course: res.data.course,
          email: res.data.email
        });
      })
      .catch((err) => {
        console.error("Error fetching student:", err);
      });
  }

  return (
    <div>
      <div className="col-md-12 mb-4 pb-2 mt-2">
        <div data-mdb-input-init className="form-outline gradient-custom-form">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Address</th>
                <th scope="col">DOB</th>
                <th scope="col">Pincode</th>
                <th scope="col">Course</th>
                <th scope="col">Email</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {newData.map((eachData, i) => (
                <tr key={eachData.id}>
                  <td>{i + 1}</td>
                  <td>{eachData.firstName}</td>
                  <td>{eachData.lastName}</td>
                  <td>
                    {eachData.addName && eachData.addName.length > 0 ? (
                      eachData.addName.map((addressObj, index) => (
                        <p key={index}>{addressObj.addAddressName}</p>
                      ))
                    ) : (
                      <p>No Address</p>
                    )}
                  </td>
                  <td>{eachData.dob}</td>
                  <td>{eachData.pincode}</td>
                  <td>{eachData.course}</td>
                  <td>{eachData.email}</td>
                  <td>
                    <Link to={`/form/${eachData.id}`}>
                      <button onClick={() => handleUpdate(eachData.id)} type="button" className="btn btn-sm btn-primary me-2">
                        <i className="fa-solid fa-pencil"></i>
                      </button>
                    </Link>
                    <button onClick={() => handleDelete(eachData.id)} type="button" className="btn btn-sm btn-danger">
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
