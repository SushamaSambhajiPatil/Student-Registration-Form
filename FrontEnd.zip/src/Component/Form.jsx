import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';

export default function Form() {
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    addName: [{ addAddressName: "" }], 
    dob: "",
    pincode: "",
    course: "",
    email: ""
  });
  
  const [students, setStudents] = useState([]);
  const [errors, setErrors] = useState({});
  const [id, setId] = useState(null); 
  const [redirect, setRedirect] = useState(false);

  useEffect(() => {
    fetchStudents();
  }, []);

  function handleChange(e) {
    setData({ ...data, [e.target.id]: e.target.value });
  }

  function fetchStudents() {
    axios.get("http://localhost:8080/student/")
      .then((res) => {
        setStudents(res.data);
        console.log("Fetched students:", res.data);
      })
      .catch((err) => {
        console.error("Error fetching students:", err);
      });
  }

  function validateForm() {
    let formErrors = {};
    let valid = true;
 
    setErrors(formErrors);
    return valid;
  }

  function handleAddressChange(e, index) {
    const { value } = e.target;
    const updatedAddress = [...data.addName]; 
    updatedAddress[index] = { addAddressName: value };
    setData({ ...data, addName: updatedAddress });
  }
  
  function addAddress() {
    setData({ ...data, addName: [...data.addName, { addAddressName: "" }] }); 
  }

  function removeAddress(index) {
    const updatedAddress = [...data.addName]; 
    updatedAddress.splice(index, 1);
    setData({ ...data, addName: updatedAddress });
  }

  function handleSubmit(e) {
    e.preventDefault(); 

    if (validateForm()) {
      const request = id 
        ? axios.put(`http://localhost:8080/student/${id}`, data)
        : axios.post("http://localhost:8080/student/", data);

      request
        .then((res) => {
          console.log("Submission successful:", res.data);
          fetchStudents();
          setData({
            firstName: "",
            lastName: "",
            addName: [{ addAddressName: "" }], 
            dob: "",
            pincode: "",
            course: "",
            email: ""
          });
          setId(null);
        })
        .catch((err) => {
          console.error("Error during submission:", err.response ? err.response.data : err.message);
        });
    }
  }

  if (redirect) {
    return <Navigate to="/studentForm" />;
  }

  return (
    <div>
      <section className="h-100 bg-dark">
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col">
              <div className="card card-registration my-4">
                <div className="row g-0">
                  <div className="col-xl-6 d-none d-xl-block">
                    <img
                      src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                      alt="Sample photo"
                      className="img-fluid"
                      style={{ marginRight: '1em' }}
                    />
                  </div>
                  <div className="col-xl-6">
                    <div className="card-body p-md-5 text-black">
                      <h3 className="mb-5 text-uppercase">Student registration form</h3>

                      <div className="row">
                        <div className="col-md-6 mb-4">
                          <div className="form-outline">
                            <label className="form-label" htmlFor="firstName">First name</label>
                            <input
                              value={data.firstName}
                              type="text"
                              id="firstName"
                              onChange={handleChange}
                              className="form-control form-control-lg"
                            />
                            {errors.firstName && <p style={{ color: "red" }}>{errors.firstName}</p>}
                          </div>
                        </div>
                        <div className="col-md-6 mb-4">
                          <div className="form-outline">
                            <label className="form-label" htmlFor="lastName">Last name</label>
                            <input
                              value={data.lastName}
                              type="text"
                              id="lastName"
                              onChange={handleChange}
                              className="form-control form-control-lg"
                            />
                            {errors.lastName && <p style={{ color: "red" }}>{errors.lastName}</p>}
                          </div>
                        </div>
                      </div>

                      {data.addName.map((addName, index) => ( 
                        <div key={index} className="mb-4">
                          <div className="form-outline">
                            <label className="form-label" htmlFor={`addName-${index}`}>Address</label>
                            <input
                              value={addName.addAddressName}
                              type="text"
                              id={`addName-${index}`}
                              onChange={(e) => handleAddressChange(e, index)}
                              className="form-control form-control-lg"
                            />
                            {errors.addName && <p style={{ color: "red" }}>{errors.addName}</p>}
                          </div>
                          <button type="button" onClick={() => removeAddress(index)} className="btn btn-danger">Remove</button>
                        </div>
                      ))}

                      <div className="form-outline mb-4">
                        <label className="form-label" htmlFor="dob">DOB</label>
                        <input
                          value={data.dob}
                          type="date"
                          id="dob"
                          onChange={handleChange}
                          className="form-control form-control-lg"
                        />
                        {errors.dob && <p style={{ color: "red" }}>{errors.dob}</p>}
                      </div>

                      <div className="form-outline mb-4">
                        <label className="form-label" htmlFor="pincode">Pincode</label>
                        <input
                          value={data.pincode}
                          type="text"
                          id="pincode"
                          onChange={handleChange}
                          className="form-control form-control-lg"
                        />
                        {errors.pincode && <p style={{ color: "red" }}>{errors.pincode}</p>}
                      </div>

                      <div className="form-outline mb-4">
                        <label className="form-label" htmlFor="course">Course</label>
                        <input
                          value={data.course}
                          type="text"
                          id="course"
                          onChange={handleChange}
                          className="form-control form-control-lg"
                        />
                        {errors.course && <p style={{ color: "red" }}>{errors.course}</p>}
                      </div>

                      <div className="form-outline mb-4">
                        <label className="form-label" htmlFor="email">Email ID</label>
                        <input
                          value={data.email}
                          type="text"
                          id="email"
                          onChange={handleChange}
                          className="form-control form-control-lg"
                        />
                        {errors.email && <p style={{ color: "red" }}>{errors.email}</p>}
                      </div>

                      <button type="button" onClick={addAddress} className="btn btn-secondary mb-3">Add Address</button>
                      
                      <div className="d-flex justify-content-end pt-3">
                        <button
                          onClick={handleSubmit}
                          type="button"
                          className="btn btn-warning btn-lg ms-2"
                        >
                          Submit form
                        </button>
                      </div>

                      <div className="mt-5">
                        <h5>List of Registered Students:</h5>
                        <ul>
                          {students.map((student, index) => (
                            <li key={index}>
                              {student.firstName} {student.lastName} - {student.email}
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
