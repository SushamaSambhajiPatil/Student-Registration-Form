import logo from './logo.svg';
import './App.css';
import Form from './Component/Form';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import StudentForm from './Component/StudentForm';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Form/>}/>
        <Route path='/studentForm' element={<StudentForm/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
