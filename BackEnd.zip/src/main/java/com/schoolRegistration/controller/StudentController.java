package com.schoolRegistration.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.schoolRegistration.dto.StudentDTO;
import com.schoolRegistration.entity.Student;
import com.schoolRegistration.service.StudentService;


@RestController
@RequestMapping("/student")
@CrossOrigin
public class StudentController {
	
	@Autowired
	private StudentService studentService;

//	get
		@GetMapping("/")
public ResponseEntity<List<Student>> getAll(){
		List<Student> stud=studentService.getAll();
		return new ResponseEntity<>(stud, HttpStatus.OK);
}
//	post
		
		@PostMapping("/")
		public ResponseEntity<Student> saveStudent(@RequestBody StudentDTO studentDTO)
		{
			Student student= new Student();
			
			student. setFirstName(studentDTO.getFirstName());
			student. setLastName(studentDTO.getLastName());
			student. setDob(studentDTO.getDob());
			student.setPincode(studentDTO.getPincode());
			student.setCourse(studentDTO.getCourse());
			student.setEmail(studentDTO.getEmail());
			student.setRegistrationAdd(studentDTO.getRegistrationAdd());
			
			
			Student saveStudent=studentService.saveStudent(student);
			return new ResponseEntity<> (saveStudent, HttpStatus.CREATED);
		}
		
		@GetMapping("/{id}")
		public ResponseEntity<Student>GetStudentById(@PathVariable long id)
		{
			Student student= studentService.getStudentById(id);
			return new ResponseEntity<>(student, HttpStatus.OK);
		}
		
		@PutMapping("/{id}")
		public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody StudentDTO studentDTO)
		{
			Student existingStudent = studentService.getStudentById(id);
			if (existingStudent==null)
			{
				return new ResponseEntity<>(existingStudent,HttpStatus.NOT_FOUND);
			}

			existingStudent.setFirstName(studentDTO.getFirstName());
			existingStudent.setLastName(studentDTO.getLastName());
			existingStudent.setDob(studentDTO.getDob());
			existingStudent.setPincode(studentDTO.getPincode());
			existingStudent.setCourse(studentDTO.getCourse());
			existingStudent.setEmail(studentDTO.getEmail());
	        existingStudent.setRegistrationAdd(studentDTO.getRegistrationAdd());
			
			
			Student updateStudent = studentService.saveStudent(existingStudent);
			return new ResponseEntity<>(updateStudent,HttpStatus.CREATED);
		}
		@DeleteMapping("/{id}")
		public ResponseEntity<Void> deleteStudent(@PathVariable long id)
		{
		  studentService.deleteStudent(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}	
}
