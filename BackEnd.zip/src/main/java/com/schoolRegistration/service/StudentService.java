package com.schoolRegistration.service;

import java.util.List;

import com.schoolRegistration.entity.Student;

public interface StudentService {

//	get
	 List<Student> getAll() ;
		
//		Post
		public Student saveStudent(Student student);

//		getById
		public Student getStudentById(long id);
		
		
//		Delete
		public void deleteStudent(long id);
}
