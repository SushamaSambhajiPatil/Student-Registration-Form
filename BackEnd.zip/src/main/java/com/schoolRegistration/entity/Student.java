package com.schoolRegistration.entity;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "students")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String firstName;
	private String lastName;
	private Date dob;
	private String pincode;
	private String course;
	private String email;
	
	@OneToMany(targetEntity = RegistrationAdd.class, cascade = CascadeType.ALL)
	@JoinColumn(name = ("id"))
	private List<RegistrationAdd> RegistrationAdd;

	public Student(Long id, String firstName, String lastName, Date dob, String pincode, String course, String email,
			List<com.schoolRegistration.entity.RegistrationAdd> registrationAdd) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.pincode = pincode;
		this.course = course;
		this.email = email;
		RegistrationAdd = registrationAdd;
	}

	public Student() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<RegistrationAdd> getRegistrationAdd() {
		return RegistrationAdd;
	}

	public void setRegistrationAdd(List<RegistrationAdd> registrationAdd) {
		RegistrationAdd = registrationAdd;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob
				+ ", pincode=" + pincode + ", course=" + course + ", email=" + email + ", RegistrationAdd="
				+ RegistrationAdd + "]";
	}
	
	
}