package com.schoolRegistration.entity;

	import jakarta.persistence.Entity;
	import jakarta.persistence.GeneratedValue;
	import jakarta.persistence.GenerationType;
	import jakarta.persistence.Id;
	import jakarta.persistence.Table;

	@Entity
	@Table(name = "regtables")
	public class RegistrationAdd {
		
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long addid;

		private String addName;

		public RegistrationAdd(Long addid, String addName) {
			super();
			this.addid = addid;
			this.addName = addName;
		}

		public RegistrationAdd() {
			
		}

		public Long getAddid() {
			return addid;
		}

		public void setAddid(Long addid) {
			this.addid = addid;
		}

		public String getAddName() {
			return addName;
		}

		public void setAddName(String addName) {
			this.addName = addName;
		}

		@Override
		public String toString() {
			return "RegistrationAdd [addid=" + addid + ", addName=" + addName + "]";
		}

		
	}


