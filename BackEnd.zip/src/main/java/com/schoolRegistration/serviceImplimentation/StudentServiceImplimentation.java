package com.schoolRegistration.serviceImplimentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.schoolRegistration.entity.Student;
import com.schoolRegistration.repository.StudentRepository;
import com.schoolRegistration.service.StudentService;

@Service
public class StudentServiceImplimentation implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

//	get
	@Override
	public List<Student> getAll() {
		List<Student> student= studentRepository.findAll();
		return student;
	}

//	Post
	@Override
	public Student saveStudent(Student student) {
		
		return studentRepository.save(student);
	}

//	getById
	@Override
	public Student getStudentById(long id) {
		Student student= studentRepository.findById(id).orElse(null);
		return student;	
		}
//Delete
	@Override
	public void deleteStudent(long id) {
		studentRepository.deleteById(id);
		
	}

	
	

	}

