package com.schoolRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
